import { foo, bar } from './module1'
import { fun1, fun2 } from './module2'
import module3 from './module3'

foo()
bar()
fun1()
fun2()
module3()
